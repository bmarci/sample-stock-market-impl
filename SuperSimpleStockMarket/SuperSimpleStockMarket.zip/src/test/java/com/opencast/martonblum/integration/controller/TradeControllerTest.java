package com.opencast.martonblum.integration.controller;

import static org.junit.jupiter.api.Assertions.*;

class TradeControllerTest {

}